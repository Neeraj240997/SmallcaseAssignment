package POM.Assignment;

import org.testng.annotations.Test;
import resources.Base;

public class Assignment extends Base  {
	
	@Test
	public void Flipkart() throws InterruptedException

	{
		driver =  initialiseDriver();
		driver =  Scenario1();
		driver.quit();
	}
	
	@Test
	public void Amazon() throws InterruptedException
	{
		driver = initialiseDriver();
		driver = Scenario1();
		driver = Scenario2();
		driver.quit();
	}
	

}
