package resources;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Base {

	public WebDriver driver;
	String flipkartPrice = "";
	String AmazonPrice = "";
	String search = "iPhone 12";

	public WebDriver initialiseDriver() {
		System.setProperty("webdriver.chrome.driver", "/Users/neerajagrawal/Downloads/chromedriver");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		return driver;
	}

	public WebDriver Scenario1() throws InterruptedException {
		driver.get("https://www.flipkart.com/");
		driver.findElement(By.xpath("//button[contains(.,'✕')]")).click();
		driver.findElement(By.xpath("//input[contains(@type,'text')]")).sendKeys(search);
		driver.findElement(By.xpath("//a[contains(@class,'_3izBDY')][1]")).click();
		System.out.println("Price = " + driver.findElement(By.xpath("//div[contains(@class,'WHN1')][1]")).getText());
		WebElement ele = driver.findElement(By.xpath("//a[contains(@class,'_1fQZEK')][1]"));
		Actions actions = new Actions(driver);
		actions.moveToElement(ele).click().build().perform();
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> it = windows.iterator();
		String parent = it.next();
		String child = it.next();
		driver.switchTo().window(child);
		driver.findElement(By.xpath("//button[contains(.,'ADD TO CART')]")).click();
		driver.findElement(By.xpath("//input[contains(@class,'_253qQJ')]")).clear();
		driver.findElement(By.xpath("//input[contains(@class,'_253qQJ')]")).sendKeys("2");
		flipkartPrice = driver.findElement(By.xpath(
				"/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[5]/div[1]/span[1]/div[1]/div[1]/span[1]"))
				.getText();
		System.out.println("Flipkart Price = " + flipkartPrice);
		return driver;
	}

	public WebDriver Scenario2() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(search);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("(//span[contains(@class,'a-size-medium a-color-base a-text-normal')])[2]"))
				.click();
		Set<String> window1 = driver.getWindowHandles();
		Iterator<String> it1 = window1.iterator();
		String parentID = it1.next();
		String childID = it1.next();
		String Child2 = it1.next();
		driver.switchTo().window(Child2);
		driver.findElement(By.xpath("//input[contains(@title,'Add to Shopping Cart')]")).click();
		driver.findElement(By.id("attach-close_sideSheet-link")).click();
		driver.findElement(By.id("nav-cart-count-container")).click();
		AmazonPrice = driver.findElement(By.id("sc-subtotal-amount-activecart")).getText();
		System.out.println("Amazon Price =" + AmazonPrice);

		String flip = flipkartPrice.replaceFirst(",", "");
		String finalflip = flip.replaceFirst("₹", "");
		String amaz = AmazonPrice.replaceFirst(",", "");
		String finalamazon = amaz.replaceAll(" ", "");

		Double flipkart = Double.parseDouble(finalflip);
		Double Amazon = Double.parseDouble(finalamazon);

		if (flipkart < Amazon) {
			System.out.println("Lower Price is on Flipkart = "+flipkart);
		} else {
			System.out.println("Lower Price is on Amazon = "+Amazon);
		}

		return driver;

	}
}
